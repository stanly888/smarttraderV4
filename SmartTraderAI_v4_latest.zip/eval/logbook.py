
def log_strategy(strategy, result):
    print(f"📘 策略紀錄：{strategy['model']} | {strategy['direction']} | 報酬：{result}%")
